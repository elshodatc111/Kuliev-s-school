<?php $__env->startSection('title','Hodim'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Hodim</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('adminHodimlar')); ?>">Hodimlar</a></li>
            <li class="breadcrumb-item active">Hodim</li>
        </ol>
    </nav>
</div>

<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
<section class="section dashboard">
    <div class="row">
        <div class="col-lg-8">
            <div class="card info-card sales-card">
                <div class="card-body text-center">
                    <h5 class="card-title"><i class="bi bi-person"></i> <?php echo e($User->name); ?></span></h5>
                    <table class="table table-bordered table-hover" style="font-size:12px;">
                        <tr>
                            <td style="text-align:left;width:25%;">Manzil</td>
                            <td style="text-align:right;width:25%;"><?php echo e($User->addres); ?></td>
                            <td style="text-align:left;width:25%;">Login</td>
                            <td style="text-align:right;width:25%;"><?php echo e($User->email); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;width:25%;">Telefon 1</td>
                            <td style="text-align:right;width:25%;"><?php echo e($User->phone); ?></td>
                            <td style="text-align:left;width:25%;">Telefon 2</td>
                            <td style="text-align:right;width:25%;"><?php echo e($User->phone2); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;width:25%;">Tyg'ilgan kuni</td>
                            <td style="text-align:right;width:25%;"><?php echo e($User->tkun); ?></td>
                            <td style="text-align:left;width:25%;">Lavozimi</td>
                            <td style="text-align:right;width:25%;"><?php echo e($User->type); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;width:25%;">Hodim haqida</td>
                            <td style="text-align:right;width:25%;"><?php echo e($User->about); ?></td>
                            <td style="text-align:left;width:25%;">Ishga olindi</td>
                            <td style="text-align:right;width:25%;"><?php echo e($User->created_at); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;width:25%;">Ish faoliyati</td>
                            <td style="text-align:right;width:25%;"><?php echo e($User->status); ?></td>
                            <td style="text-align:left;width:25%;">Oxirgi taxrir</td>
                            <td style="text-align:right;width:25%;"><?php echo e($User->updated_at); ?></td>
                        </tr>
                    </table>
                    <div class="row">
                        <div class="col-lg-4 pt-lg-0 pt-2">
                            <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#updatePassword"><i class="bi bi-lock"></i> Parol Yangilash</button>
                        </div>
                        <div class="col-lg-4 pt-lg-0 pt-2">
                            <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#userTaxrir"><i class="bi bi-pencil-square"></i> Taxrirlash</button>
                        </div>
                        <div class="col-lg-4 pt-lg-0 pt-2">
                            <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#ishhaqi"><i class="bi bi-cash"></i> Ish haqi to'lov</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card info-card sales-card">
                <div class="card-body text-center">
                    <h5 class="card-title"><i class="bi bi-bar-chart-line"></i> Statistika</span></h5>
                    <table class="table table-bordered table-hover"  style="font-size:12px;">
                        <tr>
                            <td style="text-align:left;width:25%;">Naqt</td>
                            <td style="text-align:right;width:25%;"><?php echo e($Kassa['naqt']); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;width:25%;">Plastik</td>
                            <td style="text-align:right;width:25%;"><?php echo e($Kassa['plastik']); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;width:25%;">Chegirma</td>
                            <td style="text-align:right;width:25%;"><?php echo e($Kassa['chegirma']); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;width:25%;">Qaytarildi</td>
                            <td style="text-align:right;width:25%;"><?php echo e($Kassa['qaytarildi']); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;width:25%;">Tashriflar</td>
                            <td style="text-align:right;width:25%;"><?php echo e($Kassa['tashriflar']); ?></td>
                        </tr>
                    </table>
                    <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#clearStatistik"><i class="bi bi-repeat"></i> Statistika tozalash</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Ish haqi to'lov -->
    <div class="modal fade" id="ishhaqi" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title w-100 text-center">Hodimga ish haqi to'lov</h5>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered text-center">
                        <tr>
                            <td colspan=2>Kassada mavjud</td>
                        </tr>
                        <tr>
                            <td>Naqt: <?php echo e($Kassa['MavjudNaqt']); ?></td>
                            <td>Plastik: <?php echo e($Kassa['MavjudPlastik']); ?></td>
                        </tr>
                    </table>
                    <form action="<?php echo e(route('adminPayHodimlarIshHaqi')); ?>" method="post" id="form1">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="Naqt" value="<?php echo e($Kassa['MavjudNaqt']); ?>">
                        <input type="hidden" name="Plastik" value="<?php echo e($Kassa['MavjudPlastik']); ?>">
                        <input type="hidden" name="user_id" value="<?php echo e($User->id); ?>">
                        <div class="row mt-3">
                            <div class="col-6">
                                <label for="summa">To'lov summasi</label>
                                <input type="text" id="summa2" name="summa" class="form-control" required>
                            </div>
                            <div class="col-6">
                                <label for="type">To'lov turi</label>
                                <select name="type" class="form-control" required>
                                    <option value="">Tanlang</option>
                                    <option value="Naqt">Naqt</option>
                                    <option value="Plastik">Plastik</option>
                                </select>
                            </div>
                            <div class="col-12 mb-3 mt-2">
                                <label for="about">To'lov summasi</label>
                                <textarea name="about" class="form-control" required></textarea>
                            </div>
                            <div class="col-6">
                                <button type="button" class="btn btn-danger w-100" data-bs-dismiss="modal">Bekor qilish</button>
                            </div>
                            <div class="col-6">
                                <button type="submit" class="btn btn-success w-100">To'lov qilish</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- User Taxrirlash -->
    <div class="modal fade" id="userTaxrir" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title w-100 text-center">Taxrirlash</h5>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('adminUpdateHodimlarUser')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e($User->id); ?>">
                        <label for="name">FIO</label>
                        <input type="text" name="name" class="form-control" value="<?php echo e($User->name); ?>" required>
                        <label for="addres" class="mt-2">Manzil</label>
                        <input type="text" name="addres" class="form-control" value="<?php echo e($User->addres); ?>" required>
                        <div class="row">
                            <div class="col-6">
                                <label for="phone" class="mt-2">Telefon raqam 1</label>
                                <input type="text" name="phone" class="form-control phone" value="<?php echo e($User->phone); ?>" required>
                            </div>
                            <div class="col-6">
                                <label for="phone2" class="mt-2">Telefon raqam 2</label>
                                <input type="text" name="phone2" class="form-control phone" value="<?php echo e($User->phone2); ?>" required>
                            </div>
                            <div class="col-6">
                                <label for="tkun" class="mt-2">Tugilgan kuni</label>
                                <input type="date" name="tkun" class="form-control" value="<?php echo e($User->tkun); ?>" required>
                            </div>
                            <div class="col-6">
                                <label for="type" class="mt-2">Lavozimi</label>
                                <select name="type" class="form-select" required>
                                    <option value="">Tanlang</option>
                                    <option value="Operator">Operator</option>
                                    <option value="Admin">Admin</option>
                                </select>
                            </div>
                        </div>
                        <label for="about" class="mt-2">Hodim haqida</label>
                        <input type="text" name="about" class="form-control" value="<?php echo e($User->about); ?>" required>
                        <div class="row mt-3">
                            <div class="col-6">
                                <button type="button" class="btn btn-danger w-100" data-bs-dismiss="modal">Bekor qilish</button>
                            </div>
                            <div class="col-6">
                                <button type="submit" class="btn btn-success w-100">Taxrirlash</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Update Password -->
    <div class="modal fade" id="updatePassword" tabindex="-1">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title w-100 text-center">Parol yangilansinmi?</h5>
                </div>
                <div class="modal-body text-center p-0">
                    <form action="<?php echo e(route('adminUpdateHodimlarPassword')); ?>" method="post" class="p-0 m-0 w-100 py-2">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e($User->id); ?>">
                        <button type="button" class="btn btn-danger" style="width:47%;" data-bs-dismiss="modal">Bekor qilish</button>
                        <button type="submit66" class="btn btn-success" style="width:47%;">Yangilash</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Clear Statistika -->
    <div class="modal fade" id="clearStatistik" tabindex="-1">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title w-100 text-center">Statistika tozalansinmi?</h5>
                </div>
                <div class="modal-body text-center p-0">
                    <form action="<?php echo e(route('adminClearHodimlarStatistik')); ?>" method="post" class="p-0 m-0 w-100 py-2">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e($User->id); ?>">
                        <button type="button" class="btn btn-danger" style="width:47%;" data-bs-dismiss="modal">Bekor qilish</button>
                        <button type="submit66" class="btn btn-success" style="width:47%;">Tozalash</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="card info-card sales-card">
        <div class="card-body text-center">
            <h5 class="card-title pb-0 mb-0">Hodimga to'langan ish haqi</h5>
            <p class="m-0 p-0 text-danger" style="font-size:10px;">(Oxirgi 35 kunda to'langan ish haqi)</p>
            <div class="table-responsive">
                <table class="table table-bordered text-center table-striped table-hover" style="font-size:14px;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>To'lov Summa</th>
                            <th>To'lov turi</th>
                            <th>To'lov vaqti</th>
                            <th>To'lov haqida</th>
                            <th>Operator</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $ishHaqi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td><?php echo e($item['summa']); ?></td>
                            <td><?php echo e($item['type']); ?></td>
                            <td><?php echo e($item['created_at']); ?></td>
                            <td><?php echo e($item['about']); ?></td>
                            <td><?php echo e($item['admin_email']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-center" colspan=6>Ish haqi to'lovlari mavjud emas.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    
</section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewCrm3\resources\views/Admin/hodim_show.blade.php ENDPATH**/ ?>