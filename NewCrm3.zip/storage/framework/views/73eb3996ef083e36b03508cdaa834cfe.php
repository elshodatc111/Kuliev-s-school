<?php $__env->startSection('title','Bosh sahifa'); ?>
<?php $__env->startSection('content'); ?>

    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Bosh sahifa</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('Techer')); ?>">Bosh sahifa</a></li>
                    <li class="breadcrumb-item active">Bosh sahifa</li>
                </ol>
            </nav>
        </div> 
    
        <section class="section dashboard">
            <div class="row">
                <div class="col-lg-4">
                    <div class="card info-card sales-card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Yangi guruhlar</span></h5>
                            <h5><?php echo e($Stat['new']); ?></h5>
                        </div>
                    </div>  
                </div>
                <div class="col-lg-4">
                    <div class="card info-card sales-card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Aktiv guruhlar</span></h5>
                            <h5><?php echo e($Stat['start']); ?></h5>
                        </div>
                    </div>  
                </div>
                <div class="col-lg-4">
                    <div class="card info-card sales-card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Yakunlangan guruhlar</span></h5>
                            <h5><?php echo e($Stat['end']); ?></h5>
                        </div>
                    </div>  
                </div>
                
                <div class="col-lg-6">
                    <div class="card info-card sales-card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Joriy oyda to'langan ish haqi</span></h5>
                            <table>
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Naqt</th>
                                        <th>Plastik</th>
                                    </tr>
                                    <tr>
                                        <td><?php echo e($Tulov['NaqtNow']); ?></td>
                                        <td><?php echo e($Tulov['PlastihNow']); ?></td>
                                    </tr>
                                </table>
                            </table>
                        </div>
                    </div>  
                </div>
                <div class="col-lg-6">
                    <div class="card info-card sales-card">
                        <div class="card-body text-center">
                            <h5 class="card-title">O'tgan oyda to'langan ish haqi</span></h5>
                            <table>
                                <table class="table table-bordered">
                                    <tr>
                                        <th>Naqt</th>
                                        <th>Plastik</th>
                                    </tr>
                                    <tr>
                                        <td><?php echo e($Tulov['NaqtEnd']); ?></td>
                                        <td><?php echo e($Tulov['PlastihEnd']); ?></td>
                                    </tr>
                                </table>
                            </table>
                        </div>
                    </div>  
                </div>
            </div>
        </section>

    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Techer.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewCrm3\resources\views/Techer/index.blade.php ENDPATH**/ ?>