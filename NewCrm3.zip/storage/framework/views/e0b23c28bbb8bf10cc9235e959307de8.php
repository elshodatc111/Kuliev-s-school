<?php $__env->startSection('title','Bosh sahifa'); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="pagetitle">
        <h1>Bosh sahifa</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('User')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Bosh sahifa</li>
            </ol>
        </nav>
    </div>
        <div class="row dashboard">
            <div class="col-lg-4 col-6">
                <div class="card info-card sales-card text-center">
                    <div class="bg-primary text-white mt-4" style="width:60px;border-radius:50%;font-size:35px;padding:5px;height:60px;margin:0 auto;">
                        <?php echo e($Stat['new']); ?>

                    </div>
                    <h5 class="card-title">Yangi guruhlar</h5>
                </div>
            </div>
            <div class="col-lg-4 col-6">
                <div class="card info-card sales-card text-center">
                    <div class="bg-warning text-white mt-4" style="width:60px;border-radius:50%;font-size:35px;padding:5px;height:60px;margin:0 auto;">
                        <?php echo e($Stat['activ']); ?>

                    </div>
                    <h5 class="card-title">Aktiv guruhlar</h5>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card info-card sales-card text-center">
                    <div class="bg-danger text-white mt-4" style="width:60px;border-radius:50%;font-size:35px;padding:5px;height:60px;margin:0 auto;">
                        <?php echo e($Stat['end']); ?>

                    </div>
                    <h5 class="card-title">Yakunlangan guruhlar</h5>
                </div>
            </div>
        </div>
        <h5 class="card-title">Chegirmali to'lovlar</h5>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $CHegirma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4">
                    <div class="card">
                        <img src="https://atko.tech/NiceAdmin/assets/img/cours.jpg" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title w-100 mb-0 p-1 text-center"><?php echo e($item['guruh_name']); ?></h5>
                            <p class="mt-0 p-0">Guruhga <span class="text-primary">
                                <?php echo e($item['tulov']); ?></span> so'm to'lov qiling va <span class="text-primary">
                                <?php echo e($item['guruh_chegirma']); ?></span> s'om chegirma oling</p>
                            <div class="w-100 text-center">
                                <form action="<?php echo e(route('Tolov')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="summa" value="<?php echo e($item['tulov']); ?>">
                                    <button class="btn btn-primary w-100 w-100 mt-1">To'lov</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <?php endif; ?>
            </div>
        
            


</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('User.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewCrm3\resources\views/User/index.blade.php ENDPATH**/ ?>