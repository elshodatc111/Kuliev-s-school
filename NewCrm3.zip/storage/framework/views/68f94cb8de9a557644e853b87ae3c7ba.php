<?php $__env->startSection('title','Bosh sahifa'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

    <div class="pagetitle">
        <h1>Bosh sahifa</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Bosh sahifa</li>
            </ol>
        </nav>
    </div>

    <?php if($Block=='true'): ?>
        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
            To'lov muddat yaqinlashmoqda. To'lovlarni o'z vaqtida amalga oshirishni unitmang!!!
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <section class="section dashboard">
        <div class="card">
            <div class="card-body pt-3">
                <div style="text-align:right;">
                    <a href="<?php echo e(route('StudentCreate')); ?>" class="btn btn-success"><i class="bi bi-person-add"></i> Yangi talaba</a>
                </div>
                <div class="table-responsive">
                    <table class="table datatable" style="font-size:14px;">
                        <thead>
                            <tr>
                                <th class="bg-primary text-white text-center">#</th>
                                <th class="bg-primary text-white text-center">FIO</th>
                                <th class="bg-primary text-white text-center">Manzil</th>
                                <th class="bg-primary text-white text-center">Telefon raqam</th>
                                <th class="bg-primary text-white text-center">Guruhlar</th>
                                <th class="bg-primary text-white text-center">Ro'yhatdan o'tdi</th>
                                <th class="bg-primary text-white text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="text-center"><?php echo e($loop->index+1); ?></td>
                                <th><?php echo e($item['name']); ?></th>
                                <td><?php echo e($item['addres']); ?></td>
                                <td class="text-center"><?php echo e($item['phone']); ?></td>
                                <td class="text-center"><?php echo e($item['guruhlar']); ?></td>
                                <td class="text-center"><?php echo e($item['created_at']); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('StudentShow',$item['id'])); ?>" class="btn btn-primary py-0 px-1">
                                        <i class="bi bi-eye"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan=7 class="text-center">Tashriflar mavjud emas.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <?php $__currentLoopData = $Rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5 class="card-title text-center">Dars jadvali: <?php echo e($value['room_name']); ?></h5>
                    <div class="table-responsive">
                        <table class="table table-bordered text-center">
                            <thaed>
                                <tr>
                                    <th  class="bg-primary text-white">Soat/Hafta</th>
                                    <th  class="bg-primary text-white">08:00</th>
                                    <th  class="bg-primary text-white">09:30</th>
                                    <th  class="bg-primary text-white">11:00</th>
                                    <th  class="bg-primary text-white">12:30</th>
                                    <th  class="bg-primary text-white">14:00</th>
                                    <th  class="bg-primary text-white">15:30</th>
                                    <th  class="bg-primary text-white">17:00</th>
                                    <th  class="bg-primary text-white">18:30</th>
                                    <th  class="bg-primary text-white">20:00</th>
                                </tr>
                            </thaed>
                            <tbody>
                                <?php $__currentLoopData = $value['hafta_kun']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hafta_kun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if($key==0): ?><th style='text-align:left;' class="bg-primary text-white">Dushanba</th>
                                        <?php elseif($key==1): ?><th style='text-align:left;' class="bg-primary text-white">Seshanba</th>
                                        <?php elseif($key==2): ?><th style='text-align:left;' class="bg-primary text-white">Chorshanba</th>
                                        <?php elseif($key==3): ?><th style='text-align:left;' class="bg-primary text-white">Payshanba</th>
                                        <?php elseif($key==4): ?><th style='text-align:left;' class="bg-primary text-white">Juma</th>
                                        <?php elseif($key==5): ?><th style='text-align:left;' class="bg-primary text-white">Shanba</th><?php endif; ?>
                                        <?php $__currentLoopData = $hafta_kun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys => $soat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($soat=='bosh'): ?>
                                            <td class="bg-danger text-white">bo'sh</td>
                                            <?php else: ?>
                                            <td class="bg-success text-white" title="<?php echo e($soat['guruh_name']); ?>" style="cursor:pointer">
                                                <a href="<?php echo e(route('AdminGuruhShow',$soat['guruh_id'] )); ?>" class="text-white">Band</a>
                                            </td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewCrm3\resources\views/Admin/index.blade.php ENDPATH**/ ?>