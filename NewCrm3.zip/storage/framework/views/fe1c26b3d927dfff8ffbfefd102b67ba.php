<?php $__env->startSection('title','Bosh sahifa'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

  <div class="pagetitle">
      <h1>Bosh sahifa</h1>
      <nav>
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Bosh sahifa</li>
          </ol>
      </nav>
  </div>

<section class="section dashboard">
    <div class="card">
        <div class="card-body text-center">
            <h5 class="card-title">Filiallar</span></h5>
            <div class="table-responsive">
                <table class="table table-bordered" style="font-size:14px;">
                    <thead class="">
                      <tr>
                          <th rowspan=2 class="align-middle bg-primary text-white"><i class="bi bi-house-door-fill"></i> Filial</th>
                          <th rowspan=2 class="align-middle bg-primary text-white"><i class="bi bi-people"></i> Tashriflar</th>
                          <th colspan=4 class="bg-primary text-white"><i class="bi bi-menu-button-wide"></i> Guruhlar</th>
                          <th colspan=2 class="bg-primary text-white"><i class="bi bi-microsoft-teams"></i> Hodimlar</th>
                      </tr>
                      <tr>
                          <th style="font-size:10px;" class="bg-warning text-white">Jami</th>
                          <th style="font-size:10px;" class="bg-warning text-white">Yangi</th>
                          <th style="font-size:10px;" class="bg-warning text-white">Aktiv</th>
                          <th style="font-size:10px;" class="bg-warning text-white">Yakunlangan</th>
                          <th style="font-size:10px;" class="bg-info text-white">O'qituvchilar</th>
                          <th style="font-size:10px;" class="bg-info text-white">Menegerlar</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $Filial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <th style="text-align:left" class="text-primary"><?php echo e($item['filial_name']); ?></th>
                          <td><?php echo e($item['user']); ?></td>
                          <td><?php echo e($item['guruhlar']); ?></td>
                          <td><?php echo e($item['yangiguruh']); ?></td>
                          <td><?php echo e($item['aktivguruh']); ?></td>
                          <td><?php echo e($item['endguruh']); ?></td>
                          <td><?php echo e($item['techer']); ?></td>
                          <td><?php echo e($item['meneger']); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>


</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewCrm3\resources\views/SuperAdmin/index.blade.php ENDPATH**/ ?>