<?php $__env->startSection('title','Bosh sahifa'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

  <div class="pagetitle">
      <h1>Bosh sahifa</h1>
      <nav>
          <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Bosh sahifa</li>
          </ol>
      </nav>
  </div>

    <?php if($Block=='true'): ?>
        <div class="alert alert-danger bg-danger text-light border-0 alert-dismissible fade show" role="alert">
            To'lov muddat yaqinlashmoqda. To'lovlarni o'z vaqtida amalga oshirishni unitmang!!!
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>


<section class="section dashboard">
    <div class="card">
        <div class="card-body text-center">
            <h5 class="card-title">Filiallar</span></h5>
            <div class="table-responsive">
                <table class="table table-bordered" style="font-size:14px;">
                    <thead class="">
                      <tr>
                          <th rowspan=2 class="align-middle bg-primary text-white"><i class="bi bi-house-door-fill"></i> Filial</th>
                          <th rowspan=2 class="align-middle bg-primary text-white"><i class="bi bi-people"></i> Tashriflar</th>
                          <th colspan=4 class="bg-primary text-white"><i class="bi bi-menu-button-wide"></i> Guruhlar</th>
                          <th colspan=2 class="bg-primary text-white"><i class="bi bi-microsoft-teams"></i> Hodimlar</th>
                      </tr>
                      <tr>
                          <th style="font-size:10px;" class="bg-warning text-white">Jami</th>
                          <th style="font-size:10px;" class="bg-warning text-white">Yangi</th>
                          <th style="font-size:10px;" class="bg-warning text-white">Aktiv</th>
                          <th style="font-size:10px;" class="bg-warning text-white">Yakunlangan</th>
                          <th style="font-size:10px;" class="bg-info text-white">O'qituvchilar</th>
                          <th style="font-size:10px;" class="bg-info text-white">Menegerlar</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $Filial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <th style="font-weight:900" class="text-primary"><?php echo e($item['filial_name']); ?></th>
                          <td><?php echo e($item['user']); ?></td>
                          <td><?php echo e($item['guruhlar']); ?></td>
                          <td><?php echo e($item['yangiguruh']); ?></td>
                          <td><?php echo e($item['aktivguruh']); ?></td>
                          <td><?php echo e($item['endguruh']); ?></td>
                          <td><?php echo e($item['techer']); ?></td>
                          <td><?php echo e($item['meneger']); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body pt-2">
            <canvas id="stakedBarChart" style="width:100%;height:400px"></canvas>
            <script>
                document.addEventListener("DOMContentLoaded", () => {
                  new Chart(document.querySelector('#stakedBarChart'), {
                    type: 'bar',
                    data: {
                      labels: [
                        '<?php echo e($SMM["oy"][0]); ?>',
                        '<?php echo e($SMM["oy"][1]); ?>',
                        '<?php echo e($SMM["oy"][2]); ?>',
                        '<?php echo e($SMM["oy"][3]); ?>',
                        '<?php echo e($SMM["oy"][4]); ?>',
                        '<?php echo e($SMM["oy"][5]); ?>'
                      ],
                      datasets: [{
                          label: 'Telegram',
                          data: [
                            '<?php echo e($SMM["svod"][0]["Telegram"]); ?>',
                            '<?php echo e($SMM["svod"][1]["Telegram"]); ?>',
                            '<?php echo e($SMM["svod"][2]["Telegram"]); ?>',
                            '<?php echo e($SMM["svod"][3]["Telegram"]); ?>',
                            '<?php echo e($SMM["svod"][4]["Telegram"]); ?>',
                            '<?php echo e($SMM["svod"][5]["Telegram"]); ?>'
                          ],
                          backgroundColor: '#6495ED',
                        },{
                          label: 'Instagram',
                          data: [
                            '<?php echo e($SMM["svod"][0]["Instagram"]); ?>',
                            '<?php echo e($SMM["svod"][1]["Instagram"]); ?>',
                            '<?php echo e($SMM["svod"][2]["Instagram"]); ?>',
                            '<?php echo e($SMM["svod"][3]["Instagram"]); ?>',
                            '<?php echo e($SMM["svod"][4]["Instagram"]); ?>',
                            '<?php echo e($SMM["svod"][5]["Instagram"]); ?>'
                          ],
                          backgroundColor: '#8B008B',
                        },{
                          label: 'Facebook',
                          data: [
                            '<?php echo e($SMM["svod"][0]["Facebook"]); ?>',
                            '<?php echo e($SMM["svod"][1]["Facebook"]); ?>',
                            '<?php echo e($SMM["svod"][2]["Facebook"]); ?>',
                            '<?php echo e($SMM["svod"][3]["Facebook"]); ?>',
                            '<?php echo e($SMM["svod"][4]["Facebook"]); ?>',
                            '<?php echo e($SMM["svod"][5]["Facebook"]); ?>'
                        ],
                          backgroundColor: '#B0E0E6',
                        },{
                          label: 'Bannerlar',
                          data: [
                            '<?php echo e($SMM["svod"][0]["Bannerlar"]); ?>',
                            '<?php echo e($SMM["svod"][1]["Bannerlar"]); ?>',
                            '<?php echo e($SMM["svod"][2]["Bannerlar"]); ?>',
                            '<?php echo e($SMM["svod"][3]["Bannerlar"]); ?>',
                            '<?php echo e($SMM["svod"][4]["Bannerlar"]); ?>',
                            '<?php echo e($SMM["svod"][5]["Bannerlar"]); ?>'
                        ],
                          backgroundColor: '#FFD700',
                        },{
                          label: 'Tanishlar',
                          data: [
                            '<?php echo e($SMM["svod"][0]["Tanishlar"]); ?>',
                            '<?php echo e($SMM["svod"][1]["Tanishlar"]); ?>',
                            '<?php echo e($SMM["svod"][2]["Tanishlar"]); ?>',
                            '<?php echo e($SMM["svod"][3]["Tanishlar"]); ?>',
                            '<?php echo e($SMM["svod"][4]["Tanishlar"]); ?>',
                            '<?php echo e($SMM["svod"][5]["Tanishlar"]); ?>'
                        ],
                          backgroundColor: '#00FF00',
                        },{
                          label: 'Boshqalar',
                          data: [
                            '<?php echo e($SMM["svod"][0]["Boshqa"]); ?>',
                            '<?php echo e($SMM["svod"][1]["Boshqa"]); ?>',
                            '<?php echo e($SMM["svod"][2]["Boshqa"]); ?>',
                            '<?php echo e($SMM["svod"][3]["Boshqa"]); ?>',
                            '<?php echo e($SMM["svod"][4]["Boshqa"]); ?>',
                            '<?php echo e($SMM["svod"][5]["Boshqa"]); ?>'
                        ],
                          backgroundColor: '#2F4F4F',
                        },
                      ]
                    },
                    options: {
                      plugins: {title: {display: true,text: 'Markazga tashriflar'},},
                      responsive: true,
                      scales: {x: {stacked: true,},y: {stacked: true}}
                    }
                  });
                });
            </script>
        </div>
    </div>

</section>


</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewCrm3\resources\views/SuperAdmin/index.blade.php ENDPATH**/ ?>