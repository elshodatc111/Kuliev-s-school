<?php $__env->startSection('title','Statistika'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Statistika</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('filial')); ?>">Filiallar</a></li>
            <li class="breadcrumb-item active">Statistika</li>
        </ol>
    </nav>
</div> 
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title w-100 text-center">Oylik Tashriflar</h5>
                        <canvas id="pieChart" style="max-height: 400px;"></canvas>
                        <script>
                            document.addEventListener("DOMContentLoaded", () => {
                            new Chart(document.querySelector('#pieChart'), {
                                type: 'pie',
                                data: {
                                labels: [
                                    'Telegram',
                                    'Facebook',
                                    'Instagram',
                                    'Tanishlar',
                                    'Bannerlar',
                                    'Boshqa'
                                ],
                                datasets: [{
                                    label: 'Oylik tashriflar',
                                    data: [
                                        <?php echo e($OylikTashriflar['Telegram']); ?>,
                                        <?php echo e($OylikTashriflar['Facebook']); ?>,
                                        <?php echo e($OylikTashriflar['Instagram']); ?>,
                                        <?php echo e($OylikTashriflar['Tanishlar']); ?>,
                                        <?php echo e($OylikTashriflar['Bannerlar']); ?>,
                                        <?php echo e($OylikTashriflar['Boshqalar']); ?>,
                                    ],
                                    backgroundColor: [
                                        '#289FD5','#4867AA','#C032AE','#F4CA16','#8CF416','#16F4D6'
                                    ],
                                    hoverOffset: 4
                                }]
                                }
                            });
                            });
                        </script>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title w-100 text-center">Oylik to'lovlar</h5>
                        <canvas id="doughnutChart" style="max-height: 400px;"></canvas>
                        <script>
                            document.addEventListener("DOMContentLoaded", () => {
                            new Chart(document.querySelector('#doughnutChart'), {
                                type: 'doughnut',
                                data: {
                                labels: [
                                    'Naqt',
                                    'Plastik',
                                    'Payme'
                                ],
                                datasets: [{
                                    label: 'Oylik to\'lovlar',
                                    data: [
                                        <?php echo e($OylikTulov['Naqt']); ?>,
                                        <?php echo e($OylikTulov['Plastik']); ?>,
                                        <?php echo e($OylikTulov['Payme']); ?>

                                    ],
                                    backgroundColor: ['green','#F4AF0F','#44BBC2'],
                                    hoverOffset: 4
                                }]
                                }
                            });
                            });
                        </script>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body text-center">
                <h5 class="card-title mb-0 pb-0">Kunlik to'lovlar</h5>
                <canvas id="barChart" style="max-height: 400px;"></canvas>
                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                        new Chart(document.querySelector('#barChart'), {
                            type: 'bar',
                            data: {
                            labels: [
                                    '<?php echo e($KunlikStatistika["kunlar"][0]); ?>',
                                    '<?php echo e($KunlikStatistika["kunlar"][1]); ?>',
                                    '<?php echo e($KunlikStatistika["kunlar"][2]); ?>',
                                    '<?php echo e($KunlikStatistika["kunlar"][3]); ?>',
                                    '<?php echo e($KunlikStatistika["kunlar"][4]); ?>',
                                    '<?php echo e($KunlikStatistika["kunlar"][5]); ?>'
                                ],
                            datasets: [{
                                    label: "Naqt to'lov",
                                    data: [
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][1]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][2]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][3]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][4]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][5]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][6]); ?>'
                                    ],
                                    backgroundColor: ['#0000F6']
                                },{
                                    label: "Plastik to'lov",
                                    data: [
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][1]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][2]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][3]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][4]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][5]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][6]); ?>'
                                    ],
                                    backgroundColor: ['#006262']
                                },{
                                    label: "Payme to'lov",
                                    data: [
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][1]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][2]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][3]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][4]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][5]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][6]); ?>'
                                    ],
                                    backgroundColor: ['#21B3B8']
                                },{
                                    label: 'Chegirmalar',
                                    data: [
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][1]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][2]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][3]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][4]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][5]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][6]); ?>'
                                    ],
                                    backgroundColor: ['#F4CA16']
                                },{
                                    label: "Qaytarilgan to'lovlar",
                                    data: [
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][1]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][2]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][3]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][4]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][5]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][6]); ?>'
                                    ],
                                    backgroundColor: ['#EB4C42']
                                }
                            ]
                            },
                            options: {scales: {y: {beginAtZero: true}}}
                        });
                    });
                </script>
                <div class="table-responsive">
                    <table class="table table-bordered mt-3" style="font-size:12px">
                        <tr>
                            <th style="text-align:left">Status</th>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun1)); ?>"><?php echo e($KunlikStatistika["kunlar"][0]); ?></a></td>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun2)); ?>"><?php echo e($KunlikStatistika["kunlar"][1]); ?></a></td>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun3)); ?>"><?php echo e($KunlikStatistika["kunlar"][2]); ?></a></td>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun4)); ?>"><?php echo e($KunlikStatistika["kunlar"][3]); ?></a></td>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun5)); ?>"><?php echo e($KunlikStatistika["kunlar"][4]); ?></a></td>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun6)); ?>"><?php echo e($KunlikStatistika["kunlar"][5]); ?></a></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Naqt</th>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][1]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][2]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][3]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][4]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][5]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][6]); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Plastik</th>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][1]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][2]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][3]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][4]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][5]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][6]); ?></td>
                        </tr>
                        
                        <tr>
                            <th style="text-align:left">Payme</th>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][1]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][2]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][3]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][4]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][5]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][6]); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Chegirma</th>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][1]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][2]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][3]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][4]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][5]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][6]); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Qaytarildi</th>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][1]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][2]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][3]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][4]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][5]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][6]); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        
        <div class="card">
            <div class="card-body text-center">
                <h5 class="card-title mb-0 pb-0">Kunlik to'lovlar</h5>
                <canvas id="oyliktulovlar" style="max-height: 400px;"></canvas>
                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                        new Chart(document.querySelector('#oyliktulovlar'), {
                            type: 'bar',
                            data: {
                            labels: ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'Iyun'],
                            datasets: [{
                                    label: 'Naqt to\'lov',
                                    data: [65, 59, 80, 81, 56, 55],
                                    backgroundColor: ['#0000F6']
                                },{
                                    label: 'Plastik to\'lov',
                                    data: [65, 59, 80, 81, 56, 55],
                                    backgroundColor: ['#006262']
                                },{
                                    label: 'Payme to\'lov',
                                    data: [65, 59, 80, 81, 56, 55],
                                    backgroundColor: ['#21B3B8']
                                },{
                                    label: 'Chegirmalar',
                                    data: [65, 59, 80, 81, 56, 55],
                                    backgroundColor: ['#F4CA16']
                                },{
                                    label: 'Qaytarilgan to\'lovlar',
                                    data: [65, 59, 80, 81, 56, 55],
                                    backgroundColor: ['#EB4C42']
                                },{
                                    label: 'Xarajatalar',
                                    data: [65, 59, 80, 81, 56, 55],
                                    backgroundColor: ['#E000f0']
                                },{
                                    label: 'Ish haqi',
                                    data: [65, 59, 80, 81, 56, 55],
                                    backgroundColor: ['#00fff0']
                                },{
                                    label: 'Daromad',
                                    data: [65, 59, 80, 81, 56, 55],
                                    backgroundColor: ['#00ff00']
                                }
                            ]
                            },
                            options: {scales: {y: {beginAtZero: true}}}
                        });
                    });
                </script>
                <div class="table-responsive">
                    <table class="table table-bordered mt-3" style="font-size:12px">
                        <tr>
                            <th style="text-align:left">Status</th>
                            <th>02-04</th>
                            <th>03-04</th>
                            <th>04-04</th>
                            <th>05-04</th>
                            <th>06-04</th>
                            <th>07-04</th>
                        </tr>
                        <tr>
                            <th style="text-align:left">Naqt</th>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Plastik</th>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                        </tr>
                        
                        <tr>
                            <th style="text-align:left">Payme</th>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Chegirma</th>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Qaytarildi</th>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Xarajatlar</th>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Ish haqi</th>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Daromad</th>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                            <td>100 000</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewCrm3\resources\views/SuperAdmin/statistik/index.blade.php ENDPATH**/ ?>