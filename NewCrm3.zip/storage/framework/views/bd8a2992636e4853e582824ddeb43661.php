<?php $__env->startSection('title','Statistika'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Statistika</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('filial')); ?>">Filiallar</a></li>
            <li class="breadcrumb-item active">Statistika</li>
        </ol>
    </nav>
</div> 
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title w-100 text-center">Oylik Tashriflar</h5>
                        <canvas id="pieChart" style="max-height: 400px;"></canvas>
                        <script>
                            document.addEventListener("DOMContentLoaded", () => {
                            new Chart(document.querySelector('#pieChart'), {
                                type: 'pie',
                                data: {
                                labels: [
                                    'Telegram',
                                    'Facebook',
                                    'Instagram',
                                    'Tanishlar',
                                    'Bannerlar',
                                    'Boshqa'
                                ],
                                datasets: [{
                                    label: 'Oylik tashriflar',
                                    data: [
                                        <?php echo e($OylikTashriflar['Telegram']); ?>,
                                        <?php echo e($OylikTashriflar['Facebook']); ?>,
                                        <?php echo e($OylikTashriflar['Instagram']); ?>,
                                        <?php echo e($OylikTashriflar['Tanishlar']); ?>,
                                        <?php echo e($OylikTashriflar['Bannerlar']); ?>,
                                        <?php echo e($OylikTashriflar['Boshqalar']); ?>,
                                    ],
                                    backgroundColor: [
                                        '#289FD5','#4867AA','#C032AE','#F4CA16','#8CF416','#16F4D6'
                                    ],
                                    hoverOffset: 4
                                }]
                                }
                            });
                            });
                        </script>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title w-100 text-center">Oylik to'lovlar</h5>
                        <canvas id="doughnutChart" style="max-height: 400px;"></canvas>
                        <script>
                            document.addEventListener("DOMContentLoaded", () => {
                            new Chart(document.querySelector('#doughnutChart'), {
                                type: 'doughnut',
                                data: {
                                labels: [
                                    'Naqt',
                                    'Plastik',
                                    'Payme'
                                ],
                                datasets: [{
                                    label: 'Oylik to\'lovlar',
                                    data: [
                                        <?php echo e($OylikTulov['Naqt']); ?>,
                                        <?php echo e($OylikTulov['Plastik']); ?>,
                                        <?php echo e($OylikTulov['Payme']); ?>

                                    ],
                                    backgroundColor: ['green','#F4AF0F','#44BBC2'],
                                    hoverOffset: 4
                                }]
                                }
                            });
                            });
                        </script>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body text-center">
                <h5 class="card-title mb-0 pb-0">Kunlik to'lovlar</h5>
                <canvas id="barChart" style="max-height: 400px;"></canvas>
                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                        new Chart(document.querySelector('#barChart'), {
                            type: 'bar',
                            data: {
                            labels: [
                                    '<?php echo e($KunlikStatistika["kunlar"][0]); ?>',
                                    '<?php echo e($KunlikStatistika["kunlar"][1]); ?>',
                                    '<?php echo e($KunlikStatistika["kunlar"][2]); ?>',
                                    '<?php echo e($KunlikStatistika["kunlar"][3]); ?>',
                                    '<?php echo e($KunlikStatistika["kunlar"][4]); ?>',
                                    '<?php echo e($KunlikStatistika["kunlar"][5]); ?>'
                                ],
                            datasets: [{
                                    label: "Naqt to'lov",
                                    data: [
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][1]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][2]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][3]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][4]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][5]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][6]); ?>'
                                    ],
                                    backgroundColor: ['#0000F6']
                                },{
                                    label: "Plastik to'lov",
                                    data: [
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][1]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][2]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][3]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][4]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][5]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][6]); ?>'
                                    ],
                                    backgroundColor: ['#006262']
                                },{
                                    label: "Payme to'lov",
                                    data: [
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][1]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][2]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][3]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][4]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][5]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Payme"][6]); ?>'
                                    ],
                                    backgroundColor: ['#21B3B8']
                                },{
                                    label: 'Chegirmalar',
                                    data: [
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][1]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][2]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][3]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][4]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][5]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][6]); ?>'
                                    ],
                                    backgroundColor: ['#F4CA16']
                                },{
                                    label: "Qaytarilgan to'lovlar",
                                    data: [
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][1]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][2]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][3]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][4]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][5]); ?>',
                                        '<?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][6]); ?>'
                                    ],
                                    backgroundColor: ['#EB4C42']
                                }
                            ]
                            },
                            options: {scales: {y: {beginAtZero: true}}}
                        });
                    });
                </script>
                <div class="table-responsive">
                    <table class="table table-bordered mt-3" style="font-size:12px">
                        <tr>
                            <th style="text-align:left">Status</th>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun1)); ?>"><?php echo e($KunlikStatistika["kunlar"][0]); ?></a></td>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun2)); ?>"><?php echo e($KunlikStatistika["kunlar"][1]); ?></a></td>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun3)); ?>"><?php echo e($KunlikStatistika["kunlar"][2]); ?></a></td>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun4)); ?>"><?php echo e($KunlikStatistika["kunlar"][3]); ?></a></td>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun5)); ?>"><?php echo e($KunlikStatistika["kunlar"][4]); ?></a></td>
                            <td><a href="<?php echo e(route('statistikaKun',$Kun6)); ?>"><?php echo e($KunlikStatistika["kunlar"][5]); ?></a></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Naqt</th>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][1]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][2]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][3]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][4]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][5]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Naqt"][6]); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Plastik</th>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][1]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][2]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][3]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][4]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][5]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Plastik"][6]); ?></td>
                        </tr>
                        
                        <tr>
                            <th style="text-align:left">Payme</th>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][1]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][2]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][3]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][4]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][5]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Payme"][6]); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Chegirma</th>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][1]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][2]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][3]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][4]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][5]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Chegirma"][6]); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Qaytarildi</th>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][1]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][2]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][3]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][4]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][5]); ?></td>
                            <td><?php echo e($KunlikStatistika["Tulovlar"]["Qaytarilgan"][6]); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        
        <div class="card">
            <div class="card-body text-center">
                <h5 class="card-title mb-0 pb-0">Oylik to'lovlar</h5>
                <canvas id="oyliktulovlar" style="max-height: 400px;"></canvas>
                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                        new Chart(document.querySelector('#oyliktulovlar'), {
                            type: 'bar',
                            data: {
                            labels: [
                                '<?php echo e($OylikStatistiakOylar[0]); ?>',
                                '<?php echo e($OylikStatistiakOylar[1]); ?>',
                                '<?php echo e($OylikStatistiakOylar[2]); ?>',
                                '<?php echo e($OylikStatistiakOylar[3]); ?>',
                                '<?php echo e($OylikStatistiakOylar[4]); ?>',
                                '<?php echo e($OylikStatistiakOylar[5]); ?>'
                            ],
                            datasets: [{
                                    label: 'Naqt to\'lov',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Naqt']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Naqt']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Naqt']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Naqt']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Naqt']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Naqt']); ?>

                                    ],
                                    backgroundColor: ['#0000F6']
                                },{
                                    label: 'Plastik to\'lov',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Plastik']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Plastik']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Plastik']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Plastik']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Plastik']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Plastik']); ?>,
                                    ],
                                    backgroundColor: ['#006262']
                                },{
                                    label: 'Payme to\'lov',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Payme']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Payme']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Payme']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Payme']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Payme']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Payme']); ?>,
                                    ],
                                    backgroundColor: ['#21B3B8']
                                },{
                                    label: 'Chegirmalar',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Chegirma']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Chegirma']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Chegirma']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Chegirma']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Chegirma']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Chegirma']); ?>,
                                    ],
                                    backgroundColor: ['#F4CA16']
                                },{
                                    label: 'Qaytarilgan to\'lovlar',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Qaytarilgan']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Qaytarilgan']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Qaytarilgan']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Qaytarilgan']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Qaytarilgan']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Qaytarilgan']); ?>,
                                    ],
                                    backgroundColor: ['#EB4C42']
                                },{
                                    label: 'Xarajatalar',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Xarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Xarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Xarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Xarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Xarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Xarajat']); ?>,
                                    ],
                                    backgroundColor: ['#E000f0']
                                },{
                                    label: 'Umumiy xarajat',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['UmumiyXarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['UmumiyXarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['UmumiyXarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['UmumiyXarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['UmumiyXarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['UmumiyXarajat']); ?>,
                                    ],
                                    backgroundColor: ['#E000fF']
                                },{
                                    label: 'Ish haqi',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['IshHaqi']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['IshHaqi']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['IshHaqi']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['IshHaqi']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['IshHaqi']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['IshHaqi']); ?>,
                                    ],
                                    backgroundColor: ['#00fff0']
                                },{
                                    label: 'Daromad',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Daromat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Daromat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Daromat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Daromat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Daromat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Daromat']); ?>,
                                    ],
                                    backgroundColor: ['#00ff00']
                                }
                            ]
                            },
                            options: {scales: {y: {beginAtZero: true}}}
                        });
                    });
                </script>
                <div class="table-responsive">
                    <table class="table table-bordered mt-3" style="font-size:12px">
                        <tr>
                            <th style="text-align:left">Status</th>
                            <th><?php echo e($OylikStatistiakOylar[0]); ?></th>
                            <th><?php echo e($OylikStatistiakOylar[1]); ?></th>
                            <th><?php echo e($OylikStatistiakOylar[2]); ?></th>
                            <th><?php echo e($OylikStatistiakOylar[3]); ?></th>
                            <th><?php echo e($OylikStatistiakOylar[4]); ?></th>
                            <th><?php echo e($OylikStatistiakOylar[5]); ?></th>
                        </tr>
                        <tr>
                            <th style="text-align:left">Naqt</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Naqt']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Naqt']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Naqt']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Naqt']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Naqt']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Naqt']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Plastik</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Plastik']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Plastik']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Plastik']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Plastik']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Plastik']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Plastik']); ?></td>
                        </tr>
                        
                        <tr>
                            <th style="text-align:left">Payme</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Payme']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Payme']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Payme']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Payme']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Payme']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Payme']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Chegirma</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Chegirma']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Chegirma']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Chegirma']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Chegirma']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Chegirma']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Chegirma']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Qaytarildi</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Qaytarilgan']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Qaytarilgan']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Qaytarilgan']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Qaytarilgan']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Qaytarilgan']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Qaytarilgan']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Xarajatlar</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Xarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Xarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Xarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Xarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Xarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Xarajat']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Umumiy xarajatlar</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['UmumiyXarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['UmumiyXarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['UmumiyXarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['UmumiyXarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['UmumiyXarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['UmumiyXarajat']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Ish haqi</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['IshHaqi']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['IshHaqi']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['IshHaqi']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['IshHaqi']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['IshHaqi']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['IshHaqi']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Daromad</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Daromat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Daromat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Daromat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Daromat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Daromat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Daromat']); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewCrm3\resources\views/SuperAdmin/statistik/index.blade.php ENDPATH**/ ?>