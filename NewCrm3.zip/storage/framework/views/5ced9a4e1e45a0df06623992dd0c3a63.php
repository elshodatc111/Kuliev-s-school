<?php $__env->startSection('title','O\'qituvchi'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>O'qituvchi</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('Admin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('AdminTecher')); ?>">O'qituvchilar</a></li>
            <li class="breadcrumb-item active">O'qituvchi</li>
        </ol>
    </nav>
</div>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
<section class="section dashboard">
    <div class="row">
        <div class="col-lg-8">
            <div class="card info-card sales-card">
                <div class="card-body text-center">
                    <h5 class="card-title"><?php echo e($Techer->name); ?></span></h5>
                    <table class="table table-bordered text-center table-hover" style="font-size:14px;">
                        <tr>
                            <td style="text-align:left;width:25%;">Manzil</td>
                            <td style="text-align:right;width:25%;"><?php echo e($Techer->addres); ?></td>
                            <td style="text-align:left;width:25%;">Login</td>
                            <td style="text-align:right;width:25%;"><?php echo e($Techer->email); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;width:25%;">Telefon raqam</td>
                            <td style="text-align:right;width:25%;"><?php echo e($Techer->phone); ?></td>
                            <td style="text-align:left;width:25%;">Telefon raqam</td>
                            <td style="text-align:right;width:25%;"><?php echo e($Techer->phone2); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;width:25%;">Tyg'ilgan kuni</td>
                            <td style="text-align:right;width:25%;"><?php echo e($Techer->tkun); ?></td>
                            <td style="text-align:left;width:25%;">O'qituvchi haqida</td>
                            <td style="text-align:right;width:25%;"><?php echo e($Techer->about); ?></td>
                        </tr>
                    </table>
                    <div class="row">
                        <div class="col-lg-6 mt-lg-0 bt-2">
                            <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#editpassword">Parolni yangilash</button>
                        </div>
                        <div class="col-lg-6 mt-lg-0 bt-2">
                            <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#taxrirlash">Taxrirlash</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card info-card sales-card">
                <div class="card-body text-center">
                    <h5 class="card-title">Statistika</span></h5>
                    <table class="table table-bordered text-center table-hover" style="font-size:14px;">
                        <tr>
                            <td style="text-align:left">Yangi guruhlari</td>
                            <td style="text-align:right"><?php echo e($Statistika['new']); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left">Aktiv guruhlari</td>
                            <td style="text-align:right"><?php echo e($Statistika['activ']); ?></td>
                        </tr>
                        <tr>
                            <td style="text-align:left">Yakunlangan guruhlari</td>
                            <td style="text-align:right"><?php echo e($Statistika['end']); ?></td>
                        </tr>
                    </table>
                    <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#ishhaqi">Ish haqi to'lov</button>
                </div>
            </div>
        </div>
    </div>
    <!-- O'qituvchini Taxrirlash -->
    <div class="modal fade" id="taxrirlash" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title w-100 text-center">O'qituvchini taxrirlash</h5>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('AdminTecherUpdate')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e($Techer->id); ?>">
                        <label for="name">FIO</label>
                        <input type="text" name="name" class="form-control" value="<?php echo e($Techer->name); ?>" required>
                        <label for="addres" class="mt-2">Manzil</label>
                        <input type="text" name="addres" class="form-control" value="<?php echo e($Techer->addres); ?>" required>
                        <div class="row">
                            <div class="col-lg-6">
                                <label for="phone" class="mt-2">Telefon raqam 1</label>
                                <input type="text" name="phone" class="form-control phone" value="<?php echo e($Techer->phone); ?>" required>
                            </div>
                            <div class="col-lg-6">
                                <label for="phone2" class="mt-2">Telefon raqam 2</label>
                                <input type="text" name="phone2" class="form-control phone" value="<?php echo e($Techer->phone2); ?>" required>
                            </div>
                        </div>
                        <label for="tkun" class="mt-2">Tugilgan kuni</label>
                        <input type="date" name="tkun" class="form-control" value="<?php echo e($Techer->tkun); ?>" required>
                        <label for="about" class="mt-2">O'qituvchi haqida</label>
                        <input type="text" name="about" class="form-control" value="<?php echo e($Techer->about); ?>" required>
                        <div class="row mt-3">
                            <div class="col-6">
                                <button type="button" class="btn btn-danger w-100" data-bs-dismiss="modal">Bekor qilish</button>
                            </div>
                            <div class="col-6">
                                <button type="submit" class="btn btn-success w-100">Taxrirlash</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Ish haqi to'lov -->
    <div class="modal fade" id="ishhaqi" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title w-100 text-center">O'qituvchiag ish haqi to'lov</h5>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered text-center">
                        <tr>
                            <td colspan=2>Kassada mavjud</td>
                        </tr>
                        <tr>
                            <td>Naqt: <?php echo e($Statistika['Naqt']); ?></td>
                            <td>Plastik: <?php echo e($Statistika['Plastik']); ?></td>
                        </tr>
                    </table>
                    <form action="<?php echo e(route('AdminTecherPay')); ?>" method="post" id="form1">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="Naqt" value="<?php echo e($Statistika['Naqt']); ?>">
                        <input type="hidden" name="Plastik" value="<?php echo e($Statistika['Plastik']); ?>">
                        <input type="hidden" name="user_id" value="<?php echo e($Techer->id); ?>">
                        <div class="row mt-3">
                            <div class="col-12">
                                <label for="summa">Guruhni tanlang</label>
                                <select name="guruh_id" class="form-select mb-2" required>
                                    <option value="guruh_id">Tanlang</option>
                                    <?php $__currentLoopData = $Guruh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item['id']); ?>"><?php echo e($item['guruh_name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-6">
                                <label for="summa">To'lov summasi</label>
                                <input type="text" id="summa2" name="summa" class="form-control" required>
                            </div>
                            <div class="col-6">
                                <label for="type">To'lov turi</label>
                                <select name="type" class="form-control" required>
                                    <option value="">Tanlang</option>
                                    <option value="Naqt">Naqt</option>
                                    <option value="Plastik">Plastik</option>
                                </select>
                            </div>
                            <div class="col-12 mb-3 mt-2">
                                <label for="about">To'lov haqida</label>
                                <textarea name="about" class="form-control" required></textarea>
                            </div>
                            <div class="col-6">
                                <button type="button" class="btn btn-danger w-100" data-bs-dismiss="modal">Bekor qilish</button>
                            </div>
                            <div class="col-6">
                                <button type="submit" class="btn btn-success w-100">To'lov qilish</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Edet Password -->
    <div class="modal fade" id="editpassword" tabindex="-1">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title w-100 text-center">Parol yangilansinmi?</h5>
                </div>
                <div class="modal-body text-center p-0">
                    <form action="<?php echo e(route('AdminTecherUpdatePassword')); ?>" method="post" class="p-0 m-0 w-100 py-2">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e($Techer->id); ?>">
                        <button type="button" class="btn btn-danger" style="width:47%;" data-bs-dismiss="modal">Bekor qilish</button>
                        <button type="submit66" class="btn btn-success" style="width:47%;">Yangilash</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <div class="card info-card sales-card">
        <div class="card-body text-center">
            <h5 class="card-title mb-0 pb-0">O'qituvchi guruhlari</h5>
            <p class="m-0 p-0 text-danger" style="font-size:10px;">(Guruh yakunlangandan 30 kundan so'ng guruhlar o'chiriladi)</p>
            <div class="table-responsive">
                <table class="table table-bordered text-center table-striped table-hover" style="font-size:14px;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Guruh</th>
                            <th>Boshlanish vaqti</th>
                            <th>Tugash vaqti</th>
                            <th>Talabalar</th>
                            <th>Talaba o'chirildi</th>
                            <th>Bonus</th>
                            <th>Davomad</th>
                            <th>Ish haqi</th>
                            <th>To'langan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $Guruh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td style="text-align:left;"><a href="<?php echo e(route('AdminGuruhShow',$item['id'] )); ?>"><?php echo e($item['guruh_name']); ?><a></td>
                            <td><?php echo e($item['guruh_start']); ?></td>
                            <td><?php echo e($item['guruh_end']); ?></td>
                            <td><?php echo e($item['Users']); ?></td>
                            <td><?php echo e($item['delete']); ?></td>
                            <td><?php echo e($item['Bonus']); ?></td>
                            <td><?php echo e($item['Davomat']); ?></td>
                            <td style="text-align:right"><?php echo e($item['Hisoblandi']); ?></td>
                            <td style="text-align:right"><?php echo e($item['Tulov']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center" colspan=9>Guruhlar mavjud emas.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>  

    <div class="card info-card sales-card">
        <div class="card-body text-center">
            <h5 class="card-title mb-0 pb-0">To'langan ish haqi</h5>
            <p class="m-0 p-0 text-danger" style="font-size:10px;">(Oxirgi 35 kunda to'langan ish haqi)</p>
            <div class="table-responsive">
                <table class="table table-bordered text-center table-striped table-hover" style="font-size:14px;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Guruh</th>
                            <th>To'lov Summa</th>
                            <th>To'lov turi</th>
                            <th>To'lov vaqti</th>
                            <th>To'lov haqida</th>
                            <th>Meneger</th>
                            <th>O'chirish</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $Tulov; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td style="text-align:left"><?php echo e($item['guruh']); ?></td>
                            <td><?php echo e($item['summa']); ?></td>
                            <td><?php echo e($item['type']); ?></td>
                            <td><?php echo e($item['created_at']); ?></td>
                            <td><?php echo e($item['about']); ?></td>
                            <td><?php echo e($item['admin_id']); ?></td>
                            <td>
                                <?php if($item['created_at'] >= $Time1): ?>
                                    <a href="<?php echo e(route('AdminTecherPayDel',$item['id'])); ?>" class="btn btn-danger px-1 py-0"><i class="bi bi-trash"></i></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-center" colspan=8>To'lovlar mavjud emas</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>  
    
</section>
<div class="w-100 text-center"><a href="<?php echo e(route('AdminTecherDelete',$Techer['id'])); ?>" class="btn btn-danger w-50"><i class="bi bi-trash"></i> O'qituvchini o'chirish </a></div>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewCrm3\resources\views/Admin/techer/show.blade.php ENDPATH**/ ?>