<?php $__env->startSection('title','Statistika'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Statistika</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item active">Statistika Tulovlar</li>
        </ol>
    </nav>
</div> 
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
    <section class="section dashboard">
        <div class="card">
            <div class="card-body text-center">
                <h5 class="card-title mb-0 pb-0">Oylik to'lovlar</h5>
                <canvas id="stakedBarChart"  style="width:100%;height:400px"></canvas>
                <script>
                    document.addEventListener("DOMContentLoaded", () => {
                        new Chart(document.querySelector('#stakedBarChart'), {
                            type: 'bar',
                            data: {
                            labels: [
                                '<?php echo e($OylikStatistiakOylar[0]); ?>',
                                '<?php echo e($OylikStatistiakOylar[1]); ?>',
                                '<?php echo e($OylikStatistiakOylar[2]); ?>',
                                '<?php echo e($OylikStatistiakOylar[3]); ?>',
                                '<?php echo e($OylikStatistiakOylar[4]); ?>',
                                '<?php echo e($OylikStatistiakOylar[5]); ?>'
                            ],
                            datasets: [{
                                    label: 'Naqt to\'lov',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Naqt']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Naqt']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Naqt']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Naqt']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Naqt']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Naqt']); ?>

                                    ],
                                    backgroundColor: ['#0000F6']
                                },{
                                    label: 'Plastik to\'lov',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Plastik']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Plastik']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Plastik']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Plastik']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Plastik']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Plastik']); ?>,
                                    ],
                                    backgroundColor: ['#006262']
                                },{
                                    label: 'Payme to\'lov',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Payme']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Payme']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Payme']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Payme']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Payme']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Payme']); ?>,
                                    ],
                                    backgroundColor: ['#21B3B8']
                                },{
                                    label: 'Chegirmalar',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Chegirma']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Chegirma']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Chegirma']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Chegirma']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Chegirma']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Chegirma']); ?>,
                                    ],
                                    backgroundColor: ['#F4CA16']
                                },{
                                    label: 'Qaytarilgan to\'lovlar',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Qaytarilgan']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Qaytarilgan']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Qaytarilgan']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Qaytarilgan']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Qaytarilgan']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Qaytarilgan']); ?>,
                                    ],
                                    backgroundColor: ['#EB4C42']
                                },{
                                    label: 'Xarajatalar',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Xarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Xarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Xarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Xarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Xarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Xarajat']); ?>,
                                    ],
                                    backgroundColor: ['#E000f0']
                                },{
                                    label: 'Umumiy xarajat',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['UmumiyXarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['UmumiyXarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['UmumiyXarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['UmumiyXarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['UmumiyXarajat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['UmumiyXarajat']); ?>,
                                    ],
                                    backgroundColor: ['#E000fF']
                                },{
                                    label: 'Ish haqi',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['IshHaqi']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['IshHaqi']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['IshHaqi']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['IshHaqi']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['IshHaqi']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['IshHaqi']); ?>,
                                    ],
                                    backgroundColor: ['#00fff0']
                                },{
                                    label: 'Daromad',
                                    data: [
                                        <?php echo e($OylikTulovlar['statis'][1]['Daromat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][2]['Daromat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][3]['Daromat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][4]['Daromat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][5]['Daromat']); ?>,
                                        <?php echo e($OylikTulovlar['statis'][6]['Daromat']); ?>,
                                    ],
                                    backgroundColor: ['#00ff00']
                                }
                            ]
                            },
                            options: {scales: {y: {beginAtZero: true}}}
                        });
                    });
                </script>
                <div class="table-responsive">
                    <table class="table table-bordered mt-3" style="font-size:12px">
                        <tr>
                            <th style="text-align:left">Status</th>
                            <th><?php echo e($OylikStatistiakOylar[0]); ?></th>
                            <th><?php echo e($OylikStatistiakOylar[1]); ?></th>
                            <th><?php echo e($OylikStatistiakOylar[2]); ?></th>
                            <th><?php echo e($OylikStatistiakOylar[3]); ?></th>
                            <th><?php echo e($OylikStatistiakOylar[4]); ?></th>
                            <th><?php echo e($OylikStatistiakOylar[5]); ?></th>
                        </tr>
                        <tr>
                            <th style="text-align:left">Naqt</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Naqt']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Naqt']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Naqt']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Naqt']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Naqt']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Naqt']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Plastik</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Plastik']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Plastik']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Plastik']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Plastik']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Plastik']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Plastik']); ?></td>
                        </tr>
                        
                        <tr>
                            <th style="text-align:left">Payme</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Payme']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Payme']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Payme']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Payme']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Payme']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Payme']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Chegirma</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Chegirma']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Chegirma']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Chegirma']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Chegirma']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Chegirma']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Chegirma']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Qaytarildi</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Qaytarilgan']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Qaytarilgan']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Qaytarilgan']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Qaytarilgan']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Qaytarilgan']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Qaytarilgan']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Xarajatlar</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Xarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Xarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Xarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Xarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Xarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Xarajat']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Umumiy xarajatlar</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['UmumiyXarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['UmumiyXarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['UmumiyXarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['UmumiyXarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['UmumiyXarajat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['UmumiyXarajat']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Ish haqi</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['IshHaqi']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['IshHaqi']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['IshHaqi']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['IshHaqi']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['IshHaqi']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['IshHaqi']); ?></td>
                        </tr>
                        <tr>
                            <th style="text-align:left">Daromad</th>
                            <td><?php echo e($OylikTulovlar['view'][1]['Daromat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][2]['Daromat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][3]['Daromat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][4]['Daromat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][5]['Daromat']); ?></td>
                            <td><?php echo e($OylikTulovlar['view'][6]['Daromat']); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewCrm3\resources\views/SuperAdmin/statistik/oy.blade.php ENDPATH**/ ?>