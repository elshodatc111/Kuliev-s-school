
<?php $__env->startSection('title','Statistika'); ?>
<?php $__env->startSection('content'); ?>

<main id="main" class="main">

<div class="pagetitle">
    <h1>Statistika</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('SuperAdmin')); ?>">Bosh sahifa</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('filial')); ?>">Filiallar</a></li>
            <li class="breadcrumb-item active">Statistika</li>
        </ol>
    </nav>
</div> 
<?php if(Session::has('success')): ?>
    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
<?php elseif(Session::has('error')): ?>
    <div class="alert alert-danger"><?php echo e(Session::get('error')); ?></div>
<?php endif; ?>
    <section class="section dashboard">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title w-100 text-center">Kunlik to'lovlar</h5>
                <table class="table table-bordered text-center" style="font-size:12px;">
                    <tr>
                        <th>#</th>
                        <th>Student</th>
                        <th>Summa</th>
                        <th>Type</th>
                        <th>Tulov haqida</th>
                        <th>Tulov Vaqti</th>
                        <th>Meneger</th>
                    </tr>
                    <?php $__empty_1 = true; $__currentLoopData = $Tulov; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td><?php echo e($item['User']); ?></td>
                            <td><?php echo e($item['summa']); ?></td>
                            <td><?php echo e($item['type']); ?></td>
                            <td><?php echo e($item['about']); ?></td>
                            <td><?php echo e($item['created_at']); ?></td>
                            <td><?php echo e($item['Admiin']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </section>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('SuperAdmin.layout.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NewCrm3\resources\views/SuperAdmin/statistik/kunlik.blade.php ENDPATH**/ ?>